========
OVERVIEW
========

This project is a randomly-generated maze game. From the main menu,
you can select Easy, Medium, or Hard Mode. Once in the maze, your only
goal is to explore until you find the Exit Block.


====
TEAM
====

Alex Kabak
Chris Klassen


========
CONTROLS
========

Keyboard
--------

WASD - Movement
Mouse - Look around
Left Click - Zoom In
Right Click - Zoom Out
Middle Click - Reset Zoom
Z - Toggle Night/Day
X - Toggle Fog
Home - Reset to beginning of maze
G - Toggle Ghost Mode 


Gamepad
-------

Left Thumbstick - Movement
Right Thumbstick - Look around
Left Trigger - Zoom In
Right Trigger - Zoom Out
Click Right Thumbstick - Reset Zoom
Left Shoulder - Toggle Night/Day
Right Shoulder - Toggle Fog
Start - Reset to beginning of maze
Y - Toggle Ghost Mode